module.exports = {
  secretAdmin: "finance-liansheng-key-9848",
};
